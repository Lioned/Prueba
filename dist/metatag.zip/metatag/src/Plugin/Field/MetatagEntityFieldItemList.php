<?php

namespace Drupal\metatag\Plugin\Field;

use Drupal\Core\Field\FieldItemList;

/**
 * Defines a metatag list class for better normalization targetting
 */
class MetatagEntityFieldItemList extends FieldItemList {
}
